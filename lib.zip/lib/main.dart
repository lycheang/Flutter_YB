import 'package:flutter/material.dart';
import 'package:my_app/basic_module/basic_app.dart';
import 'package:my_app/basic_module/basic_provider.dart';
import 'package:my_app/basic_module/main_screen.dart';

void main() {
  runApp(basicProvider());
}

