import 'package:flutter/material.dart';

class DetailScreen extends StatefulWidget {
  final String item;
  const DetailScreen(this.item, {super.key});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: _buildAppbar(),

      body: _buildBody(),
    );
  }

  AppBar _buildAppbar() {
    return AppBar(
      centerTitle: true,
      title: Text("YouTube Video"),
      backgroundColor: Colors.black,
      foregroundColor: Colors.white,
    );
  }

  Widget _buildBody() {
    return Scaffold();
  }
}
